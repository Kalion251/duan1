<?php 
  $URL_UPLOAD = "upload/";
?>