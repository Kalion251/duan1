<div class="container-main col l-10 m-12 c-12">
        <div class="container__filter hide-on-mobile-tablet">
          <div class="container__filter-menu">
            <span>Sắp xếp theo</span>
            <button class="container__filter-menu-btn btn container__filter-menu-btn btn--primary">Phổ biến</button>
            <button class="container__filter-menu-btn btn">Mới nhất</button>
            <button class="container__filter-menu-btn btn">Bán chạy</button>
            <div class="select-container container__filter-menu-option btn select-hover-btn">
              <span class="option-content">Giá</span>
              <i class="fa-solid fa-angle-down"></i>
              <ul class="item--option-wrapper price-sort-select">
                <li class="item--option item--option-with-check">
                  <a href="#" class="option-link">Giá: Thấp đến Cao</a>
                </li>
                <li class="item--option item--option-with-check">
                  <a href="#" class="option-link">Giá: Cao đến Thấp</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="container__filter-page">
            <span class="container__filter-page-current">1</span>
            /<span class="container__filter-page-total">7</span>
            <button class="btn btn--small prev-btn">
              <i class="fa-solid fa-angle-left"></i>
            </button>
            <button class="btn btn--small next-btn">
              <i class="fa-solid fa-angle-right"></i>
            </button>
          </div>
        </div>