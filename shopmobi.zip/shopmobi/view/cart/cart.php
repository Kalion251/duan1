<div class="container">
      <div class="grid wide">
        <div class="card-title">
          <div class="card-checkbox">
            <input type="checkbox" name="" id="">
          </div>
          <div class="card-product-title card-product-item">Sản phẩm</div>
          <div class="card-product-title">Đơn Giá</div>
          <div class="card-product-title">Số Lượng</div>
          <div class="card-product-title">Thao Tác</div>
        </div>
        <div class="card-content">

          
          <div class="card-item-product">
            <div class="card-checkbox">
              <input type="checkbox" name="" id="">
            </div>
            <div class="card-product-item card-content-info">
              <div class="card-content-img">
                <img
                  src="https://images.pexels.com/photos/15118791/pexels-photo-15118791/free-photo-of-a-person-holding-a-picture.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load"
                  alt="" class="card-product-img">
              </div>
              <span class="card-product-text">Áo thẻ nhớ micro SD (adapter SD) Áo thẻ nhớ micro SD (adapter SD Áo thẻ
                nhớ micro SD adapter SD</span>
            </div>
            <div class="card-content-action">₫99.000</div>
            <div class="card-content-action">
              <div class="product-detail-quanity">
                <div class="product-detail-quanity-count">
                  <button class="product-detail-quanity-btn">-</button>
                  <input type="number" class="product-detail-quanity-input" name="" id="" value="1">
                  <button class="product-detail-quanity-btn">+</button>
                </div>
              </div>
            </div>
            <div class="card-content-action">
              <button class="btn btn--primary">Xóa</button>
            </div>
          </div>


          <div class="card-item-product">
            <div class="card-checkbox">
              <input type="checkbox" name="" id="">
            </div>
            <div class="card-product-item card-content-info">
              <div class="card-content-img">
                <img
                  src="https://images.pexels.com/photos/15118791/pexels-photo-15118791/free-photo-of-a-person-holding-a-picture.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load"
                  alt="" class="card-product-img">
              </div>
              <span class="card-product-text">Áo thẻ nhớ micro SD (adapter SD) Áo thẻ nhớ micro SD (adapter SD Áo thẻ
                nhớ micro SD adapter SD</span>
            </div>
            <div class="card-content-action">₫99.000</div>
            <div class="card-content-action">
              <div class="product-detail-quanity">
                <div class="product-detail-quanity-count">
                  <button class="product-detail-quanity-btn">-</button>
                  <input type="number" class="product-detail-quanity-input" name="" id="" value="1">
                  <button class="product-detail-quanity-btn">+</button>
                </div>
              </div>
            </div>
            <div class="card-content-action">
              <button class="btn btn--primary">Xóa</button>
            </div>
          </div>



        </div>
      </div>
    </div>