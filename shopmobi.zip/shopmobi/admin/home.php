<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Blank Page</h1>
    <button class="btn btn-primary"><a href="../index.php" style="text-decoration: none;color: white;">Quay lại trang khách hàng</a></button>
</div>